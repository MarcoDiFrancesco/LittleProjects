package albero;

public class Albero {
	private Nodo root;

	public Nodo getRoot() {
		return root;
	}

	public void setRoot(Nodo root) {
		this.root = root;
	}
}
