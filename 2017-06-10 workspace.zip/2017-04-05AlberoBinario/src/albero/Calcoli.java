package albero;

public class Calcoli {

	public void addNodo(int intero, char carattere) {
//		Nodo nodo1 = new Nodo(intero, carattere);

		
	}

	public void print(Nodo nodo, int n, char carattere) {

	}
}
