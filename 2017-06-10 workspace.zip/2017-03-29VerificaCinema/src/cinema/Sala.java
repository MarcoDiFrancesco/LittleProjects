package cinema;

public class Sala {
	Proiezione proiezione1 = new Proiezione(10, 0, 11, 0, 1, "primoFilm");
	Proiezione proiezione2 = new Proiezione(10, 0, 11, 0, 1, "primoFilm");
	Proiezione proiezione3 = new Proiezione(10, 0, 11, 0, 1, "primoFilm");

	public Sala(int numeroBiglietti) {
		super();
	}

}
