package proveswing;

import javax.swing.JPanel;

public class RoomPanel extends JPanel {
	private static final long serialVersionUID = 1L;
	
}
