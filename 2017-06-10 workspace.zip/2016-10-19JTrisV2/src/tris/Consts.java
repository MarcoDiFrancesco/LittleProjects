package tris;

public interface Consts {
	public final int CELLS = 3;
	public final int SCREEN_WIDTH = 600;
	public final int SCREEN_HEIGHT = 600;
}
