package tris;

public enum GameStatus {
	GAME_ON, WIM, DRAW
}
