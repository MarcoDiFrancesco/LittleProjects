package tris;

public enum Player {
	X, O, NONE
}
