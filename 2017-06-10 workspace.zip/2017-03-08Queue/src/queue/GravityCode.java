package queue;

public enum GravityCode {
	GREEN, YELLOW, RED;
}
