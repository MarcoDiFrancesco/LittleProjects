package liste;

/**
 * Nodo che pu� essere usato sia per la coda che per la pila
 * */
 class Node<T> {
	T value;
	Node<T> next;
	
	public Node(T value, Node<T> next) {
		super();
		this.value = value;
		this.next = next;
	}







}
