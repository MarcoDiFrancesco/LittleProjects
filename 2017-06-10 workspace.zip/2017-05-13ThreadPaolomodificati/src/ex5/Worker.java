package ex5;

public class Worker {

}
