package es5;

public class Queue {

}
