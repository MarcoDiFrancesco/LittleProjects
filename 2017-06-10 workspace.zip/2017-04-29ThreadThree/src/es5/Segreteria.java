package es5;

public class Segreteria {
	private Queue<Integer> queue;

	public Segreteria(Queue<Integer>);
		
}
