package es1;

public class NonThreadWorker {

}
