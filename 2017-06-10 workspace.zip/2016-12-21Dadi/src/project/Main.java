package project;

public class Main {
	public static void main(String[] args) {
	//	Dadi tiro1 = new Dadi(6);
	//	System.out.println(tiro1.getUltimaFaccia());
	//	System.out.println(tiro1.getNumeroFacce());
	}
}

/*
 * Tizio e Caio partecipano ad un torneo di gioco con i dadi. Il torneo prevede
 * una serie di partite a due e in ciascuna, i giocatori lanciano per 3 volte i
 * propri dadi ( 2 dadi e 3 lanci per ciascun giocatore). Vince la partita il
 * giocatore che nei tre lanci ha totalizzato pi� punti, se per� lanciando i
 * dadi escono due facce uguali, il giocatore ottiene il diritto a rilanciare.
 * Fai giocare Tizio e Caio per almeno 5 partite e calcola chi vince pi� spesso.
 * Per realizzare il gioco progetta la classe Dado, nella quale indicare
 * l�ultima faccia uscita e il numero di facce del dado. Il dado viene lanciato
 * con il metodo lancia che produce un numero casuale corrispondente alla faccia
 * uscita nel lancio. Inoltre, � richiesto un metodo equals che permetta di
 * gestire il caso dell�uscita di facce uguali. Realizza la classe giocatore che
 * ha due dadi ed il punteggio totale, calcolato dopo ogni lancio della coppia
 * di dadi. La classe ha un metodo giocaDadi che lancia i due dati, calcola i
 * punti e verifica se sono uscite le stesse facce. Progetta e realizza un main
 * program per simulate le partite e calcolare chi vince.
 */