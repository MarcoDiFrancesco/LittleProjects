package figuregeometriche;

public abstract class FiguraGeometrica{
public abstract float calcolaArea();

}
