package figuregeometriche;

public class Main {

	public static void main(String[] args) {
		Quadrato quadrato = new Quadrato(20);
		float area = quadrato.calcolaArea();
		System.out.println(area);
		quadrato = new Quadrato(30);
//		System.out.println(fg.calcolaArea());
//		fg = new Quadrato(20);
//F		System.out.println(fg.calcolaArea());

	}

}
