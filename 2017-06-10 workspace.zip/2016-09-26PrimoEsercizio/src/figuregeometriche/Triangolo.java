package figuregeometriche;

public class Triangolo {

}
