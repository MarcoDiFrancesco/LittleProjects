package figuregeometriche;

public class Rettangolo {

	public float calcolaArea() {
		float lato = 0;
		return lato;
	}
}
