package tartaruga;

public class Main {

	public static void main(String[] args) {
		Tarta linea = new Tarta(100, 100);

		linea.sposta(60, 10);

	}
}