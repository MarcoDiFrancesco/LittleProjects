package liste;

public class Nodo {
	String nome;
	Nodo next;

	public Nodo(String nome) {
		super();
		this.nome = nome;
	}

}
