package barche;

public class Barca {
	int nome, nazionalit�, lunghezza, stazza, tipologia;

}
