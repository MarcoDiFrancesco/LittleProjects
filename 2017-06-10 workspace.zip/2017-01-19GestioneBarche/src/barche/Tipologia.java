package barche;

public enum Tipologia {
	vela, motore;
	
}
