<?php
$dbserver = "localhost";
$dbnickname = "root";
$dbpassword = "";
$dbname = "DiFrancescoDatabase";


$connect = new mysqli($dbserver,$dbnickname,$dbpassword,$dbname);
?>
