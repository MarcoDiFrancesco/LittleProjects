<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Di Francesco Es 3 pag 325</title>
    </head>
    <body>
        <form method="post" action="massimi.php">
            <p><input type="text" name="primoNumero"></p>
            <p><input type="text" name="secondoNumero"></p>
            <p><input type="submit" name="submit" value="Calcola"></p>

        </form>
    </body>
</html>
