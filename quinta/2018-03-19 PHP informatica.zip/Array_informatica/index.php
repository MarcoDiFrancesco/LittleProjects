<!DOCTYPE html>
<!--
dato un'array che contiene 5 interi ordinati, scrivere un programma
PHP che inserisca un numero(esempio simbolo dollaro) che
lo inserisca in una cerca poszione con ArraySrais
-->
<!--
array di 20 temperature espresse in interi, calcolare la media e stampare, 5 più alte, 5 più basse, utilizzare la funzione sort
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" action="print.php">
            <p>Posizione dell'array da modificare: <input type="text" name="position" value="2"></p>
            <p>Carattere da sostituire: <input type="text" name="carattere" value="2"></p>
            
            <input type="submit" name="submit">
        </form>
    </body>
</html>
