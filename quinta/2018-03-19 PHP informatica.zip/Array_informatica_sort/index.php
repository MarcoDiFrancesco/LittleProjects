<!DOCTYPE html>
<!--
dato un'array che contiene 5 interi ordinati, scrivere un programma
PHP che inserisca un numero(esempio simbolo dollaro) che
lo inserisca in una cerca poszione con ArraySrais
-->
<!--
array di 20 temperature espresse in interi, calcolare la media e stampare, 5 più alte, 5 più basse, utilizzare la funzione sort
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="post" action="print.php">
            <p>Temperatura 1: <input type="text" name="t1" value="11"></p>
            <p>Temperatura 2: <input type="text" name="t2" value="12"></p>
            <p>Temperatura 3: <input type="text" name="t3" value="3"></p>
            <p>Temperatura 4: <input type="text" name="t4" value="40"></p>
            <p>Temperatura 5: <input type="text" name="t5" value="5"></p>
            <p>Temperatura 6: <input type="text" name="t6" value="6"></p>
            <p>Temperatura 7: <input type="text" name="t7" value="7"></p>
            <p>Temperatura 8: <input type="text" name="t8" value="8"></p>
            <p>Temperatura 9: <input type="text" name="t9" value="9"></p>
            <p>Temperatura 10: <input type="text" name="t10" value="10"></p>
            <p>Temperatura 11: <input type="text" name="t11" value="1"></p>
            <p>Temperatura 12: <input type="text" name="t12" value="2"></p>
            <p>Temperatura 13: <input type="text" name="t13" value="3"></p>
            <p>Temperatura 14: <input type="text" name="t14" value="4"></p>
            <p>Temperatura 15: <input type="text" name="t15" value="5"></p>
            <p>Temperatura 16: <input type="text" name="t16" value="6"></p>
            <p>Temperatura 17: <input type="text" name="t17" value="7"></p>
            <p>Temperatura 18: <input type="text" name="t18" value="8"></p>
            <p>Temperatura 19: <input type="text" name="t19" value="9"></p>
            <p>Temperatura 20: <input type="text" name="t20" value="10"></p>
            
            <input type="submit" name="submit">
        </form>
    </body>
</html>
