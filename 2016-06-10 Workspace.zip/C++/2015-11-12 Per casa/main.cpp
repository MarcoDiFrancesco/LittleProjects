//     Scrivere un programma, con l'uso di un sottoprogramma che:
//     1)Permetta all'utente di inserire 20 numeri interi a piacere in un vettore A
//     2)Calocla la potenza, con esponente a picere, dai 20 numeri e li inserisca in un secondo vettore B

#include <cstdlib>
#include <iostream>

using namespace std;
int A[20],B[20];
int i;
void RIEMPIVETTORE ()
{
for (i=0;i<20;i++)
cin>>A[i];
}
void RIEMPIVETTORE(int c)
{
for (i=0;i<20;i++)
 B[i]=A[i]*c;
}
int main()
{
int potenza (int b,int e);
int a,t,b,e,p,f;
t=-1;
while (a>0) 
{
t=t*b;
e-i;
}
return p;
}
RIEMPIVETTORE(f)
RIEMPIVETTORE()
system (�PAUSE�)
return EXIT_SUCCESS;
}
