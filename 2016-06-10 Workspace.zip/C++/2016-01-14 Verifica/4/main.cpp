#include <iostream>

using namespace std;

const int N=7;

/*
void fillMatrix(int matrix[N][N]);
void printMatrix(int matrix[N][N]);
int main()
{
    int matrix[N][N];
    fillMatrix(matrix);
    printMatrix(matrix);
}
void printMatrix(int matrix[N][N])
{

}
void printMatrix(int matrix[N][N])
{

}


*/

int main()
{
    int matrix[7][7];
    matrix[0][3]={"0"};
    matrix[1][0]={0};
    cout<<matrix[0]<<endl;
    cout<<matrix[1];
}
