#include <cstdlib>
#include <iostream>

using namespace std;

int tab[10];
int a,A,i,b;
void scrivivettore()
    {
    for(i=0;i<=9;i++)    
    {
    cout<<tab[i]<<"\t";
    }
    }
void riempivettore();
int main()
{
    for(i=0;i<=10;i++)     // riempie il vettore 
    {A[i]=(i+1)*b;} 
}
int main()
{
