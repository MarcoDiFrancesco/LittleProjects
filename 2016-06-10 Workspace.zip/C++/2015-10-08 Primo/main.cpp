#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{
    int a, b, c, d;
    cout<<"Inserisci primo numero \t\t";
    cin>> a;
    cout<<"inserisci secondo numero \t";
    cin>> b;
    c = a + b;
    cout<<"\n\tA\t+\tB\t=\tC";
    cout<<"\t",d;
    cout<< "\n";
    system("pause");
    return EXIT_SUCCESS;
}
