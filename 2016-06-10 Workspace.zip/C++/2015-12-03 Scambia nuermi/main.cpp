#include <cstdlib>
#include <iostream>

using namespace std;
void swap(int a6,int  

int main(int argc, char *argv[])

{
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
