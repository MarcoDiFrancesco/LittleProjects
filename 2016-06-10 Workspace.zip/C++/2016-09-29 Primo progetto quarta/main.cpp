#include <iostream>

using namespace std;

int main()
{
cout<<"1--> Processo richiede risorsa\n";
cout<<"2--> Processo rilascia risorsa\n";
cout<<"3--> Processo termina (rilascia le sue risorse)\n";
cout<<"4--> Conoscere lo stato\n";
cout<<"5--> Uscire\n";
}
