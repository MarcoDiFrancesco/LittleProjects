/*
Programma che dati N numeri interi inseriti in un vettore, individui il minimo, il massimo e calcoli la media
 -N � scelto dall'utente!!
 -L'utende pu� decidere di:
           - ripetere il programma
           - Quale calcolo effettuare
*/

#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{
int i,n,B;
void average(int n,int B[]);
float somma=0;
cin>>n;

for(int i=0;i<n;i++)
{
somma=somma+B;
}
}

void riempivettore()

{
for(i=0;i<=n;i=i+1)
{
cout<<B[i]<<"\t";
}
}


    system("PAUSE");
    return EXIT_SUCCESS;
}
