#include <cstdlib>
#include <iostream>

using namespace std;


int A[100],b,i;
void RIEMPIVETTORE(int b)

{

A[i]<b;

}

int main()

{

int x;

x=5;

riempivettore(x);


system("PAUSE");
return EXIT_SUCCESS;
}
