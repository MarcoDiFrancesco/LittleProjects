#include <cstdlib>
#include <iostream>

using namespace std;

int main()
int a;
{
    cin<<a
    switch(a)
    {
    case 0
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
